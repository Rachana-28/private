USE [Training_19Sep19_Pune]
GO

/****** Object:  StoredProcedure [8420].[DeleteBill]    Script Date: 11/23/2019 9:23:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure[8420].[DeleteBill]
 @BillNo varchar(20)
 as 
 begin

 Delete [8420].BillData where BillNo=@BillNo
 end

GO


create procedure [8420].[DeleteInPatient]

@PatientID varchar(10)

as
begin
delete [8420].InPatient where PatientID=@PatientID
end

GO




create procedure [8420].[DeleteLab]
@PatientID varchar(20)
as
begin

Delete [8420].Lab where @PatientID=PatientID
end

GO


 create procedure [8420].[DeleteOutPatient]
 @PatientID varchar(20)
 as
 begin
 Delete [8420].OutPatient where PatientID=@PatientID
 end

GO



Create Procedure [8420].[DeletePatient]

@PatientID varchar(10)

as 
begin 
Delete [8420].Patient where PatientID=@PatientID
end

GO




create procedure [8420].[GetDoctor]
as
 begin
 select * from [8420].Doctor
 end

GO


create procedure [8420].[GetLab]
 As
Begin
select * From [8420].Lab
end

GO


create procedure [8420].[GetRoom]
 as
 begin
 select * from [8420].RoomData
 end


GO

create procedure [8420].[Insert_InPatient]
(
@PatientID varchar(10),
@RoomNo varchar(20),
@DoctorID varchar(20),
@AdmissionDate date,
@DischargeDate date,
@LabNo varchar(20),
@Amount Real
)
as 
begin
insert into [8420].InPatient values(@PatientID,@RoomNo,@DoctorID,@AdmissionDate,@DischargeDate,@LabNo,@Amount)
end

GO



create procedure [8420].[InsertBill]
(
 @BillNo varchar(20) ,
 @PatientID varchar(20),
 @PatientType varchar(20),
 @DoctorID varchar(20),
 @DoctorFee Real,
 @RoomCharge Real,
 @OperationCharges Real,
 @MedicineFee Real,
 @TotalDays int,
 @LabFee Real,
 @TotalAmount Real)
 as 
 begin
 insert into [8420].BillData values(
 @BillNo,
 @PatientID ,
 @PatientType ,
 @DoctorID ,
 @DoctorFee ,
 @RoomCharge ,
 @OperationCharges ,
 @MedicineFee ,
 @TotalDays ,
 @LabFee ,
 @TotalAmount)
 end


GO

create Procedure [8420].[InsertLab]
 (
 @LabNo varchar(20) ,
 @PatientID varchar(10) ,
 @DoctorID varchar(20),
 @TestDate date,
 @TestType varchar(50),
 @PatientType varchar(50)
 )
 as
 begin
 insert into [8420].Lab values (@LabNo  ,
 @PatientID  ,
 @DoctorID ,
 @TestDate ,
 @TestType ,
 @PatientType )
 end

GO




create procedure [8420].[InsertOutPatient]
 (
 @PatientID varchar(10),
 @TreatmentDate date ,
 @DoctorID varchar(20),
 @LabNo varchar(20))
 as
 begin
 insert into [8420].OutPatient values(@PatientID,@TreatmentDate,@DoctorID,@LabNo)
 end

GO


CREATE Procedure [8420].[InsertPatient]
(
@PatientID varchar(20),
@PatientName varchar(20),
@Age int,
@PatientWeight numeric,
@Gender varchar(20),
@PAddress varchar(100),
@MobileNo varchar(20),
@Disease varchar(100),
@DoctorID varchar(20)) 
as 
begin 
insert into [8420].Patient values(@PatientID,@PatientName,@Age,@PatientWeight,@Gender,@PAddress,@MobileNo,@Disease,@DoctorID)
end



GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [8420].[ListBill]
 as
 begin
 select * from [8420].BillData
 end

GO


SET QUOTED_IDENTIFIER ON
GO

create procedure [8420].[ListInPatient]
as
begin
select * from [8420].Inpatient
end



GO

create procedure [8420].[ListOutPatient]
 as
 begin
 select * from [8420].OutPatient
 end

GO



create procedure [8420].[ListPatient]
As
Begin
select * From [8420].Patient
end


GO


create procedure [8420].[SelectBill]
 (
 @BillNo varchar(20) ,
 @PatientID varchar(20) output,
 @PatientType varchar(20)output,
 @DoctorID varchar(20)output,
 @DoctorFee Real output,
 @RoomCharge Real output,
 @OperationCharges Real output,
 @MedicineFee Real output,
 @TotalDays int output,
 @LabFee Real output,
 @TotalAmount real output)
 as 
 begin
select @PatientID=PatientID,
 @PatientType=PatientType ,
 @DoctorID=DoctorID ,
 @DoctorFee=DoctorFee ,
 @RoomCharge=RoomCharge ,
 @OperationCharges= OperationCharges ,
 @MedicineFee=MedicineFee ,
 @TotalDays=TotalDays ,
 @LabFee=LabFee ,
 @TotalAmount=TotalAmount 
 from [8420].BillData where @BillNo=BillNo
 end

GO





create Procedure [8420].[SelectInPatient]
(
@RoomNo varchar(20) output,
@DoctorID varchar(20) output,
@AdmissionDate date output,
@DischargeDate date output,
@LabNo varchar(20) output,
@Amount Real output,
@PatientID varchar(10)) 
as 
begin 
Select @RoomNo=RoomNo,@DoctorID=DoctorID,@AdmissionDate=AdmissionDate,@DischargeDate=DischargeDate,@LabNo=LabNo,@Amount=Amount
from [8420].InPatient where PatientID=@PatientID
end




GO



create procedure [8420].[SelectLab]
 (
 @LabNo varchar(20) output ,
 @PatientID varchar(10) ,
 @DoctorID varchar(20) output,
 @TestDate date output,
 @TestType varchar(50) output,
 @PatientType varchar(50) output
 )
 as 
 begin 
 select  
 @LabNo=LabNo,
 @DoctorID=DoctorID ,
 @TestDate = TestDate,
 @TestType =TestType,
 @PatientType =PatientType
 from [8420].Lab where  @PatientID=PatientID
 end 

GO


create procedure [8420].[SelectOutPatient]
 (
 @PatientID varchar(10),
 @TreatmentDate date output,
 @DoctorID varchar(20) output,
 @LabNo varchar(20) output)
 as
 begin
 select @TreatmentDate=TreatmentDate,@DoctorID=DoctorID,@LabNo=LabNo 
 from [8420].OutPatient where PatientID=@PatientID
 end

GO




create Procedure [8420].[SelectPatient]
 (
 @PatientID varchar(20),
@PatientName varchar(20) output,
@Age int output,
@PatientWeight numeric output,
@Gender varchar(20) output,
@PAddress varchar(100) output,
@MobileNo varchar(20) output,
@Disease varchar(100) output,
@DoctorID varchar(20) output) 
as 
begin 
select  @PatientName=PatientName, @Age=Age,@PatientWeight=PatientWeight,@Gender=Gender,@PAddress=PAddress,@MobileNo=MobileNo, @Disease=Disease, @DoctorID=DoctorID 
 from [8420].Patient where PatientID= @PatientID 
end


GO


create Procedure [8420].[SelectPatientByDoctor]
(
@PatientID varchar(20) output,
@PatientName varchar(20) output,
@Age int output,
@PatientWeight numeric output,
@Gender varchar(20) output,
@PAddress varchar(100) output,
@MobileNo varchar(20) output,
@Disease varchar(100) output,
@DoctorID varchar(20)) 
as 
begin 
select  @PatientName=PatientName, @Age=Age,@PatientWeight=PatientWeight,@Gender=Gender,@PAddress=PAddress,@MobileNo=MobileNo, @Disease=Disease,@PatientID=PatientID 
 from [8420].Patient where DoctorID= @DoctorID 
end


GO


create procedure [8420].[UpdateBill]
 (
 @BillNo varchar(20) ,
 @PatientID varchar(20),
 @PatientType varchar(20),
 @DoctorID varchar(20),
 @DoctorFee Real,
 @RoomCharge Real,
 @OperationCharges Real,
 @MedicineFee Real,
 @TotalDays int,
 @LabFee Real,
 @TotalAmount Real)
 as 
 begin
 update [8420].BillData set BillNo=@BillNo,
 
 PatientType=@PatientType ,
 DoctorID=@DoctorID ,
 DoctorFee=@DoctorFee ,
 RoomCharge=@RoomCharge ,
 OperationCharges= @OperationCharges ,
 MedicineFee=@MedicineFee ,
 TotalDays=@TotalDays ,
 LabFee=@LabFee ,
 TotalAmount=@TotalAmount where PatientID=@PatientID
 end

GO

create procedure [8420].[UpdateInPatient]
(
@PatientID varchar(10),
@RoomNo varchar(20),
@DoctorID varchar(20),
@AdmissionDate date,
@DischargeDate date,
@LabNo varchar(20),
@Amount Real
)
as 
begin
update [8420].InPatient set RoomNo=@RoomNo,DoctorID=@DoctorID,AdmissionDate=@AdmissionDate,DischargeDate=@DischargeDate,LabNo=@LabNo,Amount=@Amount where PatientID=@PatientID
end

GO


create procedure [8420].[UpdateLab]
(
 @LabNo varchar(20) ,
 @PatientID varchar(10) ,
 @DoctorID varchar(20),
 @TestDate date,
 @TestType varchar(50),
 @PatientType varchar(50)
 )
 as 
 begin 
 update [8420].Lab
 set
 
 PatientID=@PatientID ,
 DoctorID=@DoctorID ,
TestDate=  @TestDate ,
 TestType=@TestType ,
 PatientType=@PatientType 
 where @LabNo=LabNo
 end

GO

create procedure [8420].[UpdateOutPatient]
 (
 @PatientID varchar(10),
 @TreatmentDate date ,
 @DoctorID varchar(20),
 @LabNo varchar(20))
 as
 begin
 update [8420].OutPatient set  TreatmentDate=@TreatmentDate,DoctorID=@DoctorID,LabNo=@LabNo where PatientID=@PatientID
 end

GO






create Procedure [8420].[UpdatePatient]
(
@PatientID varchar(20),
@PatientName varchar(20),
@Age int,
@PatientWeight numeric,
@Gender varchar(20),
@PAddress varchar(100),
@MobileNo varchar(20),
@Disease varchar(100),
@DoctorID varchar(20)) 
as 
begin 
update [8420].Patient set PatientName=@PatientName,Age=@Age,PatientWeight=@PatientWeight,Gender=@Gender,PAddress=@PAddress,MobileNo=@MobileNo,Disease=@Disease,DoctorID=@DoctorID where PatientID= @PatientID 
end

GO


