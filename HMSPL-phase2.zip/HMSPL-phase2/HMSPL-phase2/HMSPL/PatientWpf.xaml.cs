﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using HMSBAL;
using HMSEntity;
using Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class PatientWpf : Window
    {
        HMSBal bal = null;
        public PatientWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();




                if (txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtPatientName.Text == string.Empty || txtMobileNo.Text == string.Empty ||
                     txtAge.Text == string.Empty || txtWeight.Text == string.Empty || txtAddress.Text == string.Empty || txtDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordAdded;
                    objPatient.PatientID = txtPatientId.Text;
                    objPatient.DoctorID = txtDoctorId.Text;
                    objPatient.PatientName = txtPatientName.Text;
                    objPatient.MobileNo = txtMobileNo.Text;
                   
                    if (rbmale.IsChecked ==  true)
                    {
                        objPatient.Gender = "Male";
                    }
                    else if(rbfemale.IsChecked == true)
                    {
                        objPatient.Gender = "Female";
                    }
                    else
                    {
                        MessageBox.Show("Gender is Needed");
                    }


                    objPatient.Age = int.Parse(txtAge.Text);
                    objPatient.Weight = Convert.ToDouble(txtWeight.Text);
                        
                    objPatient.Address = txtAddress.Text;
                    objPatient.Disease = txtDisease.Text;



                    RecordAdded = HMSBal.AddPatientBAL(objPatient);
                    if (RecordAdded == true)
                    {
                        MessageBox.Show("Patient record added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be added.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient objPatient = new Patient();




                if (txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtPatientName.Text == string.Empty || txtMobileNo.Text == string.Empty  || txtAge.Text == string.Empty || txtWeight.Text == string.Empty || txtAddress.Text == string.Empty || txtDisease.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordUpdated;

                    objPatient.PatientID = txtPatientId.Text;
                    objPatient.DoctorID = txtDoctorId.Text;
                    objPatient.PatientName = txtPatientName.Text;
                    objPatient.MobileNo = txtMobileNo.Text;

                    if (rbmale.IsChecked == true)
                    {
                        objPatient.Gender = "Male";
                    }
                    else if (rbfemale.IsChecked == true)
                    {
                        objPatient.Gender = "Female";
                    }
                    else
                    {
                        MessageBox.Show("Gender is Needed");
                    }
                    objPatient.Age = int.Parse(txtAge.Text);
                    objPatient.Weight = Convert.ToDouble(txtWeight.Text);
                    objPatient.Address = txtAddress.Text;
                    objPatient.Disease = txtDisease.Text;



                    RecordUpdated = HMSBal.UpdatePatientBAL(objPatient);
                    if (RecordUpdated == true)
                    {
                        MessageBox.Show("Patient record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be updated.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Patient objPatient = new Patient();
            try
            {
                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("patient id required");
                }
                else
                {

                    string PatientId;
                    //
                    bool patientDeleted;
                    //
                    PatientId = txtPatientId.Text;
                    //
                    patientDeleted = HMSBal.DeletePatientBAL(PatientId);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {

            Patient objPatient = new Patient();

            try
            {

                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("patient id required");
                }
                else
                {

                    string PatientId;

                    PatientId = txtPatientId.Text;
                    objPatient = HMSBal.SearchPatientbyPatientIDBAL(PatientId);
                    if (objPatient != null)
                    {
                        txtDoctorId.Text = objPatient.DoctorID;
                        txtPatientName.Text = objPatient.PatientName;
                        txtMobileNo.Text = objPatient.MobileNo;
                        if (objPatient.Gender == "Male")
                        {
                            rbmale.IsChecked = true;
                        }
                        else
                        {
                            rbfemale.IsChecked = true;
                        }
                        txtAge.Text = Convert.ToInt32(objPatient.Age).ToString();
                        txtWeight.Text = Convert.ToDouble(objPatient.Weight).ToString();
                        txtAddress.Text = objPatient.Address;
                        txtDisease.Text = objPatient.Disease;
                    }

                    else
                    {
                        MessageBox.Show("Patient record couldn't be found.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //public Patient SearchPatientbyDoctorIDDAL(string DoctorId)
        //{
        //    Patient objPatient = null;
        //    SqlConnection Con = null;
        //    try
        //    {
        //        Con = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
        //        SqlCommand Com = new SqlCommand("[8420].SelectPatientByDoctor", Con);
        //        Com.CommandType = CommandType.StoredProcedure;

        //        SqlParameter objSqlParam_PatientID = new SqlParameter("@PatientID", SqlDbType.VarChar, 20);
        //        SqlParameter objSqlParam_DoctorID = new SqlParameter("@DoctorID", SqlDbType.VarChar, 20);
        //        SqlParameter objSqlParam_PatientName = new SqlParameter("@PatientName", SqlDbType.VarChar, 20);
        //        SqlParameter objSqlParam_MobileNo = new SqlParameter("@MobileNo", SqlDbType.VarChar, 20);
        //        SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
        //        SqlParameter objSqlParam_Age = new SqlParameter("@Age", SqlDbType.Int);
        //        SqlParameter objSqlParam_Weight = new SqlParameter("@PatientWeight", SqlDbType.Float);
        //        SqlParameter objSqlParam_Address = new SqlParameter("@PAddress", SqlDbType.VarChar, 100);
        //        SqlParameter objSqlParam_Disease = new SqlParameter("@Disease", SqlDbType.VarChar, 100);

        //        objSqlParam_PatientID.Direction = ParameterDirection.Output;
        //        objSqlParam_DoctorID.Direction = ParameterDirection.Input;
        //        objSqlParam_PatientName.Direction = ParameterDirection.Output;
        //        objSqlParam_MobileNo.Direction = ParameterDirection.Output;
        //        objSqlParam_Gender.Direction = ParameterDirection.Output;
        //        objSqlParam_Age.Direction = ParameterDirection.Output;
        //        objSqlParam_Weight.Direction = ParameterDirection.Output;
        //        objSqlParam_Address.Direction = ParameterDirection.Output;
        //        objSqlParam_Disease.Direction = ParameterDirection.Output;




        //        Com.Parameters.Add(objSqlParam_PatientID);
        //        Com.Parameters.Add(objSqlParam_DoctorID);
        //        Com.Parameters.Add(objSqlParam_PatientName);
        //        Com.Parameters.Add(objSqlParam_MobileNo);
        //        Com.Parameters.Add(objSqlParam_Gender);
        //        Com.Parameters.Add(objSqlParam_Age);
        //        Com.Parameters.Add(objSqlParam_Weight);
        //        Com.Parameters.Add(objSqlParam_Address);
        //        Com.Parameters.Add(objSqlParam_Disease);


        //        objSqlParam_DoctorID.Value = DoctorId;

        //        Con.Open();
        //        Com.ExecuteNonQuery();
        //        objPatient = new Patient();
        //        objPatient.PatientID = objSqlParam_PatientID.Value as string;
        //        objPatient.DoctorID = objSqlParam_DoctorID.Value as string;
        //        objPatient.PatientName = objSqlParam_PatientName.Value as string;
        //        objPatient.MobileNo = objSqlParam_MobileNo.Value as string;
        //        objPatient.Gender = objSqlParam_Gender.Value as string;
        //        objPatient.Age = Convert.ToInt16(objSqlParam_Age.Value);
        //        objPatient.Weight = float.Parse(objSqlParam_Weight.ToString());
        //        objPatient.Address = objSqlParam_Address.Value as string;
        //        objPatient.Disease = objSqlParam_Disease.Value as string;
        //    }
        //    catch (SqlException objSqlEx)
        //    {
        //        throw new HMSException(objSqlEx.Message);
        //    }
        //    finally
        //    {
        //        Con.Close();
        //    }
        //    return objPatient;
        //}

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            
            txtPatientId.Clear();
           txtDoctorId.SelectedIndex=-1;
            txtPatientName.Clear();
            txtMobileNo.Clear();
            if(rbmale.IsChecked==true)
            {
                rbmale.IsChecked = false;
            }
            else
            {
                rbfemale.IsChecked = false;
            }
          
            //rbmale.ClearValue(-1);
            txtAge.Clear();
            txtWeight.Clear();
            txtAddress.Clear();
            txtDisease.Clear();
            dgPatient.DataContext = null;
        }


        //private void GetPatient()
        //{
        //    try
        //    {
        //        List<Patient> objPatients = HMSBal.GetAllPatientBAL();
        //        if (objPatients != null)
        //        {
        //            dgPatient.ItemsSource = objPatients;
        //        }
        //        else
        //        {
        //            MessageBox.Show("No records available.");
        //        }
        //    }
        //    catch (HMSException ex)
        //    {

        //        MessageBox.Show(ex.Message);
        //    }
        //}
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }

        private void BtnGetPatient_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                
                List<Patient> objPatients = HMSBal.GetAllPatientBAL();
                if (objPatients != null)
                {
                    dgPatient.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //RefreshPatient();
            LoadDoctor();
            

        }

        //private void RefreshPatient()
        //{
        //    List<Patient> Patients = null;
        //    Patients = HMSBal.GetAllPatientBAL();
        //    if (Patients.Count > 0)
        //    {
        //        dgPatient.DataContext = Patients;
        //    }
        //    else
        //    {
        //        MessageBox.Show("No Patient Details available");
        //    }
        //}

        private void LoadDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

      
    }
}
