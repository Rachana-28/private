﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using HMSBAL;
using HMSEntity;
using Exceptions;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }




      

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtName.Text == "hms" && txtPassword.Password == "hms")

            {
                Window1 m = new Window1();

                m.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or Password");
            }
        }

        private void BtnReset_Click_1(object sender, RoutedEventArgs e)
        {
            txtName.Text = "";

            txtPassword.Password = "";
        }
       
    }
}
