﻿using HMSEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBAL;
using Exceptions;
using System.Data;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for OutPatientWpf.xaml
    /// </summary>
    public partial class OutPatientWpf : Window
    {
        HMSBal bal = null;
        public OutPatientWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }


        private void LoadDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadLab()
        {
            try
            {
                DataTable labList = HMSBal.GetLabBAL();
                txtlabno.ItemsSource = labList.DefaultView;
                txtlabno.DisplayMemberPath = labList.Columns[0].ColumnName;
                txtlabno.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnAddOutPatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient objOutPatient = new OutPatient();




                if (txtPatientId.Text == string.Empty || txtlabno.Text==string.Empty|| txtDoctorId.Text==string.Empty||txttreatmentdate.Text==string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordAdded;
                    objOutPatient.PatientID = txtPatientId.Text;
                    objOutPatient.DoctorID = txtDoctorId.Text;
                    objOutPatient.LabNo = txtlabno.Text;
                    objOutPatient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                    RecordAdded = HMSBal.AddOutPatientBAL(objOutPatient);
                    if (RecordAdded == true)
                    {
                        MessageBox.Show("OutPatient record added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("OutPatient record couldn't be added.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Clear()
        {
            txtPatientId.Clear();
            txtDoctorId.SelectedIndex = -1;
            txtlabno.SelectedIndex = -1;
            txttreatmentdate.Text = "";
            dgOutPatient.DataContext = null;
        }

        private void RefreshOutPatient()
        {
            List<OutPatient> outPatients = null;
            outPatients = HMSBal.GetAllOutPatientBAL();
            if (outPatients.Count > 0)
            {
                dgOutPatient.DataContext = outPatients;
            }
            else
            {
                MessageBox.Show("No OutPatient Details available");
            }
        }

        private void BtnSearchByPatientId_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string PatientId;
                OutPatient objOutPatient;
                PatientId = txtPatientId.Text;
                objOutPatient = HMSBal.SearchOutPatientbyPatientIDBAL(PatientId);
                if (objOutPatient != null)
                {
                    txtlabno.Text = objOutPatient.LabNo;
                    txtPatientId.Text = objOutPatient.PatientID;
                    txtDoctorId.Text = objOutPatient.DoctorID;
                    txttreatmentdate.Text = objOutPatient.TreatmentDate.ToString();
                   
                }

                else
                {
                    MessageBox.Show("OutPatient record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            txtPatientId.Focus();
           
        }

        private void BtnSearchByDoctorId_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                OutPatient objDoctor = null;
                if (txtDoctorId.Text == "select")
                    MessageBox.Show("enter doctor id  to search");
                string DoctorId = txtDoctorId.Text;


                objDoctor = HMSBal.SearchOupatientByDocIDBAL(DoctorId);//HMSBal.SearchDocByDocIDBAL(DoctorId);
                if (objDoctor != null)
                {
                    txtPatientId.Text = objDoctor.PatientID;
                    txttreatmentdate.Text = objDoctor.TreatmentDate.ToString();
                    txtlabno.Text = objDoctor.LabNo;
                    txtDoctorId.Text = objDoctor.DoctorID;

                }
                else
                {
                    MessageBox.Show("OutPatient record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnListOutPatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<OutPatient> objOutPatients = HMSBal.GetAllOutPatientBAL();
                if (objOutPatients != null)
                {
                    dgOutPatient.ItemsSource = objOutPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void BtnOutPatientUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient objOutPatient = new OutPatient();




                if (txtPatientId.Text == string.Empty || txtlabno.Text == string.Empty || txtDoctorId.Text == string.Empty || txttreatmentdate.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {

                    bool RecordUpdated;

                    objOutPatient.PatientID = txtPatientId.Text;
                    objOutPatient.DoctorID = txtDoctorId.Text;
                    objOutPatient.LabNo = txtlabno.Text;
                    objOutPatient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                    RecordUpdated = HMSBal.UpdateOutPatientBAL(objOutPatient);



                    RecordUpdated = HMSBal.UpdateOutPatientBAL(objOutPatient);
                    if (RecordUpdated == true)
                    {
                        MessageBox.Show("Patient record updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be updated.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnOutPatientDelete_Click(object sender, RoutedEventArgs e)
        {
            OutPatient objOutPatient = new OutPatient();
            try
            {
                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("patient id required");
                }
                else
                {
                    string PatientId;
                    //
                    bool patientDeleted;
                    //
                    PatientId = txtPatientId.Text;
                    //
                    patientDeleted = HMSBal.DeleteOutPatientBAL(PatientId);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDoctor();
            LoadLab();
        }
    }
}

