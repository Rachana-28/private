﻿using Exceptions;
using HMSBAL;
using HMSEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace HMSPL
{
    /// <summary>
    /// Interaction logic for LabWpf.xaml
    /// </summary>
    public partial class LabWpf : Window
    {
        public LabWpf()
        {
            InitializeComponent();
        }


        private void BtnAddLab_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lab lab = new Lab();
                if (txtLabNo.Text == string.Empty || txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtDate.Text == string.Empty || txtTestType.Text == string.Empty || txtPatientType.Text == string.Empty
                   )
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool LabAdded;
                    lab.LabNo = txtLabNo.Text;
                    lab.PatientID = txtPatientId.Text;
                    lab.DoctorID = txtDoctorId.Text;
                    lab.TestDate = Convert.ToDateTime(txtDate.Text);
                    lab.TestType = txtTestType.Text;
                    lab.PatientType = txtPatientType.Text;


                    LabAdded = HMSBal.AddLabBAL(lab);
                    if (LabAdded == true)
                    {
                        MessageBox.Show("Lab Added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Lab couldn't be Added ");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
                private void BtnUpdateLab_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lab lab = new Lab();
                if (txtLabNo.Text == string.Empty || txtPatientId.Text == string.Empty || txtDoctorId.Text == string.Empty || txtDate.Text == string.Empty || txtTestType.Text == string.Empty || txtPatientType.Text == string.Empty
                   )
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool LabUpadted;
                    lab.LabNo = txtLabNo.Text;
                    lab.PatientID = txtPatientId.Text;
                    lab.DoctorID = txtDoctorId.Text;
                    lab.TestDate = Convert.ToDateTime(txtDate.Text);
                    lab.TestType = txtTestType.Text;
                    lab.PatientType = txtPatientType.Text;


                    LabUpadted = HMSBal.UpdateLabBAL(lab);
                    if (LabUpadted == true)
                    {
                        MessageBox.Show("Lab Upadted successfully");
                    }
                    else
                    {
                        MessageBox.Show("Lab couldn't be  updated");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnDeleteLab_Click(object sender, RoutedEventArgs e)
        {
            string patientID;
            Lab lab = new Lab();
            try
            {

                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool patientDeleted;
                    //
                    patientID = txtPatientId.Text;
                    //
                    patientDeleted = HMSBal.DeleteLabBAL(patientID);
                    if (patientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

       
           

        private void BtnSearchLab_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string PatientId;
                Lab objPatient;
                PatientId = txtPatientId.Text;
                objPatient = HMSBal.SearchLabbyPatientIDBAL(PatientId);
                if (objPatient != null)
                {
                    txtLabNo.Text = objPatient.LabNo;
                    txtDoctorId.Text = objPatient.DoctorID;
                    txtLabNo.Text = objPatient.LabNo;
                    txtDate.Text = Convert.ToDateTime(objPatient.TestDate).ToString();
                    txtTestType.Text = objPatient.TestType;
                    txtPatientType.Text = objPatient.PatientType;

                }

                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtPatientId.Clear();
            txtDate.Text = "";
            txtDoctorId.SelectedValue = -1;
            txtLabNo.Clear();
            txtTestType.Clear();
            txtPatientType.Clear();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();

        }

        //private void BtnGetAllLab_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        List<Lab> objLabs = HMSBal.GetAllLabsBAL();
        //        if (objLabs != null)
        //        {
        //            dgLab.ItemsSource = objLabs;
        //        }
        //        else
        //        {
        //            MessageBox.Show("No records available.");
        //        }
        //    }
        //    catch (HMSException ex)
        //    {

        //        MessageBox.Show(ex.Message);
        //    }

        //}
        private void LoadDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //private void LoadLab()
        //{
        //    try
        //    {
        //        DataTable labList = HMSBal.GetLabBAL();
        //        txtLabNo.ItemsSource = labList.DefaultView;
        //        txtLabNo.DisplayMemberPath = labList.Columns[0].ColumnName;
        //        txtLabNo.SelectedValuePath = labList.Columns[0].ColumnName;
        //    }
        //    catch (HMSException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //}

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDoctor();
                   }

        private void BtnGetLab_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Lab> objLabs = HMSBal.GetAllLabsBAL();
                if (objLabs != null)
                {
                    dgLab.ItemsSource = objLabs;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
