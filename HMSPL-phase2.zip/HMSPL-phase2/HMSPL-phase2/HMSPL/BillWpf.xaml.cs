﻿using Exceptions;
using HMSBAL;
using HMSEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for BillWpf.xaml
    /// </summary>
    public partial class BillWpf : Window
    {
        HMSBal bal = null;
        public BillWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }

        private void BtnListBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Bill> objBills = HMSBal.GetAllBillsBAL();
                if (objBills != null)
                {
                    dgBill.ItemsSource = objBills;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        //private void BtnSearchLab_Click(object sender, RoutedEventArgs e)
        //{

        //}


        private void BtnAddBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Bill bill = new Bill();
                if (txtBillId.Text == string.Empty || txtPatientId.Text == string.Empty || txtPatientType.Text == string.Empty || txtDoctorId.Text == string.Empty || txtDoctorFee.Text == string.Empty || txtRoomcharges.Text == string.Empty ||
                   txtOperationcharges.Text == string.Empty || txtAmount.Text == string.Empty || txtMedicinefee.Text == string.Empty ||
                   txtTotaldays.Text == string.Empty || txtLabfee.Text == string.Empty || txtAmount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool BillAdded;
                    bill.BillID = txtBillId.Text;
                    bill.PatientID = txtPatientId.Text;
                    bill.PatientType = txtPatientType.Text;
                    bill.DoctorID = txtDoctorId.Text;
                    bill.DoctorFees = Convert.ToDouble(txtDoctorFee.Text);
                    bill.RoomCharges = Convert.ToDouble(txtRoomcharges.Text);
                    bill.OperationCharges = Convert.ToDouble(txtOperationcharges.Text);
                    bill.MedicineFees = Convert.ToDouble(txtMedicinefee.Text);
                    bill.TotalDays = Convert.ToInt32(txtTotaldays.Text);
                    bill.LabFees = Convert.ToDouble(txtLabfee.Text);
                    bill.TotalAmount = Convert.ToDouble(txtAmount.Text);
                    BillAdded = HMSBal.AddBillBAL(bill);
                    if (BillAdded == true)
                    {
                        MessageBox.Show("Bill added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Bill not added successfully");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdateBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Bill bill = new Bill();
                if (txtBillId.Text == string.Empty || txtPatientId.Text == string.Empty || txtPatientType.Text == string.Empty || txtDoctorId.Text == string.Empty || txtDoctorFee.Text == string.Empty || txtRoomcharges.Text == string.Empty ||
                   txtOperationcharges.Text == string.Empty || txtAmount.Text == string.Empty || txtMedicinefee.Text == string.Empty ||
                   txtTotaldays.Text == string.Empty || txtLabfee.Text == string.Empty || txtAmount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool BillUpdated;
                    bill.BillID = txtBillId.Text;
                    bill.PatientID = txtPatientId.Text;
                    bill.PatientType = txtPatientType.Text;
                    bill.DoctorID = txtDoctorId.Text;
                    bill.DoctorFees = Convert.ToDouble(txtDoctorFee.Text);
                    bill.RoomCharges = Convert.ToDouble(txtRoomcharges.Text);
                    bill.OperationCharges = Convert.ToDouble(txtOperationcharges.Text);
                    bill.MedicineFees = Convert.ToDouble(txtMedicinefee.Text);
                    bill.TotalDays = Convert.ToInt32(txtTotaldays.Text);
                    bill.LabFees = Convert.ToDouble(txtLabfee.Text);
                    bill.TotalAmount = Convert.ToDouble(txtAmount.Text);
                    BillUpdated = HMSBal.UpdateBillBAL(bill);
                    if (BillUpdated == true)
                    {
                        MessageBox.Show("Bill updated successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient couldn't be updated");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnDeleteBill_Click(object sender, RoutedEventArgs e)
        {
            string billID;
            Bill patient = new Bill();
            try
            {

                if (txtBillId.Text == string.Empty)
                {
                    MessageBox.Show("ID is Required");
                }
                else
                {
                    bool billDeleted;
                    //
                    billID = txtBillId.Text;
                    //
                    billDeleted = HMSBal.DeleteBillBAL(billID);
                    if (billDeleted == true)
                    {
                        MessageBox.Show("Bill record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Bill record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string BillId;
                Bill objBill;
                BillId = txtBillId.Text;
                objBill = HMSBal.SearchBillbyBillIDBAL(BillId);
                if (objBill != null)
                {
                    txtPatientId.Text = objBill.PatientID;
                    txtPatientType.Text = objBill.PatientType;
                    txtDoctorId.Text = objBill.DoctorID;
                    txtDoctorFee.Text = Convert.ToDouble(objBill.DoctorFees).ToString();
                    txtRoomcharges.Text = Convert.ToDouble(objBill.RoomCharges).ToString();
                    txtOperationcharges.Text = Convert.ToDouble(objBill.OperationCharges).ToString();
                    txtMedicinefee.Text = Convert.ToDouble(objBill.MedicineFees).ToString();
                    txtTotaldays.Text = Convert.ToInt32(objBill.TotalDays).ToString();
                    txtLabfee.Text = Convert.ToDouble(objBill.LabFees).ToString();
                    txtAmount.Text = Convert.ToDouble(objBill.TotalAmount).ToString();

                }

                else
                {
                    MessageBox.Show("Bill record couldn't be found.");
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtBillId.Clear();
            txtPatientId.SelectedValue = -1;
            txtPatientType.Clear();
            txtDoctorId.SelectedValue = -1;
            txtDoctorFee.Clear();
            txtRoomcharges.Clear();
            txtLabfee.Clear();
            txtOperationcharges.Clear();
            txtMedicinefee.Clear();
            txtTotaldays.Clear();
            txtAmount.Clear();
        }


        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDoctor();
            LoadPatient();
        }

        private void LoadPatient()
        {
            try
            {
                DataTable patientList = HMSBal.GetPatientBAL();
                txtPatientId.ItemsSource = patientList.DefaultView;
                txtPatientId.DisplayMemberPath = patientList.Columns[0].ColumnName;
                txtPatientId.SelectedValuePath = patientList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void BtnAdd_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void BtnDelete_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void BtnLab_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void BtnClear_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        //{

        //}








    }
}
