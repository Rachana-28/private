﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMSBAL;
using HMSEntity;
using Exceptions;
using System.Data;
using System.Data.SqlClient;

namespace HMSPL
{
    /// <summary>
    /// Interaction logic for InPatientWpf.xaml
    /// </summary>
    public partial class InPatientWpf : Window
    {
        HMSBal bal = null;

        public InPatientWpf()
        {
            InitializeComponent();
            bal = new HMSBal();
        }


        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

             //try
                //{
                //    InPatient objInPatient = new InPatient();
                //    objInPatient.PatientID = txtPatientId.Text;
                //    objInPatient.RoomNo = txtRoomNo.Text;
                //    objInPatient.DoctorID = txtDoctorId.Text;
                //    objInPatient.AdmissionDate = Convert.ToDateTime(txtAdmissionDate.Text);
                //    objInPatient.DischargeDate = Convert.ToDateTime(txtDischargeDate.Text);
                //    objInPatient.LabNo = txtLabNo.Text;
                //    objInPatient.Amount = float.Parse(txtAmount.Text);

                //    int inPatientInserted = HMSBal.AddInPatientBAL(objInPatient);



                //    if (inPatientInserted > 0)
                //    {
                //        MessageBox.Show("InPatient's Record is added..!");
                //        RefreshInPatient();
                //        Clear();
                //    }
                //    else
                //        throw new HMSException("InPatient's record not added..!");
                //}
                //catch (HMSException ex)
                //{
                //    MessageBox.Show(ex.Message);
                //}
                //catch (Exception ex)
                //{
                //    MessageBox.Show(ex.Message);
                //}


                try
            {
                InPatient patient = new InPatient();
                if (txtPatientId.Text == string.Empty || txtRoomNo.Text == string.Empty || txtDoctorId.Text == string.Empty || txtAdmissionDate.Text == string.Empty || txtDischargeDate.Text == string.Empty ||
                   txtLabNo.Text == string.Empty || txtAmount.Text == string.Empty)
                {
                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool InpatientAdded;
                    patient.PatientID = txtPatientId.Text;
                    patient.RoomNo = txtRoomNo.Text;
                    patient.DoctorID = txtDoctorId.Text;
                    patient.AdmissionDate = Convert.ToDateTime(txtAdmissionDate.Text);
                    patient.DischargeDate = Convert.ToDateTime(txtDischargeDate.Text);
                    patient.LabNo = txtLabNo.Text;
                    patient.Amount = Convert.ToDouble(txtAmount.Text);
                    InpatientAdded = HMSBal.AddInPatientBAL(patient);
                    if (InpatientAdded == true)
                    {
                        MessageBox.Show("InPatient added successfully");
                    }
                    else
                    {
                        MessageBox.Show("InPatient not added successfully");
                    }
                }

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Clear()
        {
            txtPatientId.Text = "";
            txtRoomNo.Text = "";
            txtDoctorId.Text = "";
            txtAdmissionDate.Text = "";
            txtDischargeDate.Text = "";
            txtLabNo.Text = "";
            txtAmount.Text = "";
            
        }

       

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {

            Clear();
            txtPatientId.Focus();

        }

        //private void GetDoctor()
        //{
        //    try
        //    {
        //        DataTable doctorList = HMSBal.GetDoctorBAL();
        //        txtDoctorId.ItemsSource = doctorList.DefaultView;
        //        txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
        //        txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
        //    }
        //    catch (HMSException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        //private void BtnSearchLab_Click(object sender, RoutedEventArgs e)
        //{

        //    try
        //    {
        //        InPatient objLab = null;
        //        if (txtPatientId.Text == "select")
        //            MessageBox.Show("enter inpatient id to search");
        //        string LabNo = txtPatientId.Text;
              
               
        //        objLab = HMSBal.SearchInpatientByLabNoBAL(LabNo);//HMSBal.SearchDocByDocIDBAL(DoctorId);
        //        if (objLab != null)
        //        {
        //            txtPatientId.Text = objLab.PatientID;
        //            txtRoomNo.Text = objLab.RoomNo;
        //            txtDoctorId.Text = objLab.DoctorID;
        //            txtAdmissionDate.Text = objLab.AdmissionDate.ToString();//Convert.ToDateTime(objDoctor.AdmissionDate).ToString();
        //            txtDischargeDate.Text = objLab.DischargeDate.ToString();//Convert.ToDateTime(objDoctor.DischargeDate).ToString();
        //            txtLabNo.Text = objLab.LabNo;
        //            txtAmount.Text = objLab.Amount.ToString();
        //        }

        //        else
        //        {
        //            MessageBox.Show("InPatient record couldn't be found.");
        //        }
        //    }
        //    catch (HMSException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }

        //}

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {



            try
            {
                InPatient objInPatient = new InPatient();

                if (txtPatientId.Text == string.Empty || txtRoomNo.Text == string.Empty || txtDoctorId.Text == string.Empty || txtAdmissionDate.Text == string.Empty || txtDischargeDate.Text == string.Empty || txtLabNo.Text == string.Empty || txtAmount.Text == string.Empty)
                {

                    MessageBox.Show("All Fields are required");
                }
                else
                {
                    bool RecordUpdated;
                    objInPatient.PatientID = txtPatientId.Text;
                    objInPatient.RoomNo = txtRoomNo.Text;
                    objInPatient.DoctorID = txtDoctorId.Text;
                    objInPatient.AdmissionDate = Convert.ToDateTime(txtAdmissionDate.Text);
                    objInPatient.DischargeDate = Convert.ToDateTime(txtDischargeDate.Text);
                    objInPatient.LabNo = txtLabNo.Text;
                    objInPatient.Amount = Convert.ToDouble(txtAmount.Text);
                    RecordUpdated = HMSBal.UpdateInPatientBAL(objInPatient);
                    if (RecordUpdated == true)
                    {
                        MessageBox.Show("InPatient's Detail Updated Successfully...!");
                     
                        Clear();
                    }
                    else
                    {
                        MessageBox.Show("InPatient record couldn't be updated.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            InPatient inPatient = new InPatient();
            try
            {
                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("patient id required");
                }
                else
                {

                    string PatientId;
                    //
                    bool inPatientDeleted;
                    //
                    PatientId = txtPatientId.Text;
                    //
                    inPatientDeleted = HMSBal.DeleteInPatientBAL(PatientId);
                    if (inPatientDeleted == true)
                    {
                        MessageBox.Show("Patient record deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Patient record couldn't be deleted.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnInPatient_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                List<InPatient> objInPatients = HMSBal.GetAllInPatientBAL();
                if (objInPatients != null)
                {
                    dgInPatient.ItemsSource = objInPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (HMSException ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void LoadDoctor()
        {
            try
            {
                DataTable doctorList = HMSBal.GetDoctorBAL();
                txtDoctorId.ItemsSource = doctorList.DefaultView;
                txtDoctorId.DisplayMemberPath = doctorList.Columns[0].ColumnName;
                txtDoctorId.SelectedValuePath = doctorList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void LoadLab()
        {
            try
            {
                DataTable labList = HMSBal.GetLabBAL();
                txtLabNo.ItemsSource = labList.DefaultView;
                txtLabNo.DisplayMemberPath = labList.Columns[0].ColumnName;
                txtLabNo.SelectedValuePath = labList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void LoadRoom()
        {
            try
            {
                DataTable roomList = HMSBal.GetRoomBAL();
                txtRoomNo.ItemsSource = roomList.DefaultView;
                txtRoomNo.DisplayMemberPath = roomList.Columns[0].ColumnName;
                txtRoomNo.SelectedValuePath = roomList.Columns[0].ColumnName;
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
            LoadDoctor();
            LoadLab();
            LoadRoom();
         
            

        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.Show();
            this.Hide();
        }

       
        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            InPatient objPatient = new InPatient();
            try
            {

                if (txtPatientId.Text == string.Empty)
                {
                    MessageBox.Show("patient id required");
                }
                else
                {
                    string PatientId;
                   
                    PatientId = txtPatientId.Text;
                    objPatient = HMSBal.SearchInPatientbyPatientIDBAL(PatientId);
                    if (objPatient != null)
                    {
                        txtRoomNo.Text = objPatient.RoomNo;
                        txtDoctorId.Text = objPatient.DoctorID;
                        txtAdmissionDate.Text = Convert.ToDateTime(objPatient.AdmissionDate).ToString();
                        txtDischargeDate.Text = Convert.ToDateTime(objPatient.DischargeDate).ToString();
                        txtLabNo.Text = objPatient.LabNo;
                        txtAmount.Text = Convert.ToDouble(objPatient.Amount).ToString();

                    }

                    else
                    {
                        MessageBox.Show("Patient record couldn't be found.");
                    }
                }
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
 }
