﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntity;
using Exceptions;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace HMSBAL
{
    public class HMSBal
    {
       
       
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientID == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            else if (!Regex.IsMatch(patient.PatientID, "^[0-9]{4}$"))
            {
                sb.Append("patient id should be 4 digits only\n");
                validPatient = false;
            }
            if (patient.DoctorID == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            else if (!Regex.IsMatch(patient.DoctorID, "^[0-9]{3}$"))
            {
                sb.Append("doctor id should be 3 digits only\n");
                validPatient = false;
            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient name should start with Capital.");
            }
            if (patient.MobileNo.Length < 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Mobile number must be of 10 digits.");
            }
            else if (!Regex.IsMatch(patient.MobileNo, "[6-9][0-9]{9}"))
            {
                sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                validPatient = false;
            }
            if (validPatient == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validPatient;

        }

        public static List<Lab> GetAllLabsBAL()
        {
            List<Lab> lablist;
            try
            {
                HMSDal lab = new HMSDal();
                lablist = lab.ShowDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lablist;
        }

        public static Bill SearchBillbyBillIDBAL(string billId)
        {
            Bill bill = null;

            try
            {
                if (billId != null)
                {
                    HMSDal BillDAL = new HMSDal();
                    bill = BillDAL.SearchBillbyBillIDDAL(billId);
                }
                else
                {
                    throw new HMSException("Bill Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bill;
        }




      
        public static bool AddPatientBAL(Patient patient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    HMSDal patientDAL = new HMSDal();
                    patientAdded = patientDAL.AddPatientDAL(patient);
                    return patientAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static DataTable GetPatientBAL()
        {
            DataTable patientList;
            try
            {
                HMSDal patientDAL = new HMSDal();
                patientList = patientDAL.GetPatientDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

        public static bool UpdatePatientBAL(Patient patient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    HMSDal patientDAL = new HMSDal();
                    patientUpdated = patientDAL.UpdatePatientDAL(patient);
                    return patientUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static bool DeletePatientBAL(string PatientId)
        {

            bool PatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    HMSDal patientDAL = new HMSDal();

                    PatientDeleted = patientDAL.DeletePatientDAL(PatientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid OutPatient ID");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PatientDeleted;
        }

        public static List<Patient> GetAllPatientBAL()
        {
            List<Patient> patientList;
            try
            {
                HMSDal patient = new HMSDal();
                patientList = patient.GetAllPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

        
        public static Patient SearchPatientbyPatientIDBAL(string patientId)
        {
            Patient patient = null;

            try
            {
                
                    HMSDal patientDAL = new HMSDal();
                    patient = patientDAL.SearchPatientbyPatientIDDAL(patientId);
                
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static Patient SearchPatientbyDoctorIDBAL(string doctorId)
        {
            Patient patient = null;

            try
            {
                if (doctorId != null)
                {
                    HMSDal patientDAL = new HMSDal();
                    patient = patientDAL.SearchPatientbyDoctorIDDAL(doctorId);
                }
                else
                {
                    throw new HMSException("Doctor Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }



        private static bool ValidateInPatient(InPatient inPatient)
        {

            StringBuilder sb = new StringBuilder();
            bool validInPatient = true;
            if (inPatient.PatientID == string.Empty)
            {
                validInPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient can't  be empty");
            }
            else if (!Regex.IsMatch(inPatient.PatientID, "^[0-9]{4}$"))
            {
                sb.Append("patient id should be 4 digits only\n");
                validInPatient = false;
            }
            if (inPatient.RoomNo == string.Empty)
            {
                validInPatient = false;
                sb.Append(Environment.NewLine + "RoomNo  can't be empty.");
            }
            else if (!Regex.IsMatch(inPatient.RoomNo, "^[0-9]{2}$"))
            {
                sb.Append("RoomNo should be 2 digits only\n");
                validInPatient = false;
            }
            if (inPatient.DoctorID == string.Empty)
            {
                validInPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            else if (!Regex.IsMatch(inPatient.DoctorID, "^[0-9]{3}$"))
            {
                sb.Append("doctor id should be 3 digits only\n");
                validInPatient = false;
            }
            if (inPatient.AdmissionDate == null)
            {
                sb.Append(Environment.NewLine + "Admission Date is Required");
                validInPatient = false;
            }
            if (inPatient.DischargeDate == null)
            {
                sb.Append(Environment.NewLine + "Discharge Date is Required");
                validInPatient = false;
            }
            if (inPatient.Amount <= 0)
            {
                sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                validInPatient = false;
            }
            if (validInPatient == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validInPatient;
        }



        public static bool AddInPatientBAL(InPatient Inpatient)
        {
            bool InpatientAdded = false;
            try
            {
                if (ValidateInPatient(Inpatient))
                {
                    HMSDal InpatientDAL = new HMSDal();
                    InpatientAdded = InpatientDAL.AddInPatientDAL(Inpatient);
                    return InpatientAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientAdded;
        }


        public static bool UpdateInPatientBAL(InPatient InPatient)
        {
            bool InpatientUpdated = false;
            try
            {
                if (ValidateInPatient(InPatient))
                {
                    HMSDal InpatientDAL = new HMSDal();
                    InpatientUpdated = InpatientDAL.UpdateInPatientDAL(InPatient);
                    return InpatientUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientUpdated;
        }


        public static bool DeleteInPatientBAL(string PatientId)
        {
            bool InPatientDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    HMSDal InpatientDAL = new HMSDal();

                    InPatientDeleted = InpatientDAL.DeleteInPatientDAL(PatientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid InPatient ID");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InPatientDeleted;
        }




        public static InPatient SearchInPatientbyPatientIDBAL(string patientId)
        {
            InPatient Inpatient = null;

            try
            {
                    HMSDal InpatientDAL = new HMSDal();
                    Inpatient = InpatientDAL.SearchInPatientbyPatientIDDAL(patientId);
                
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Inpatient;
        }

        public static List<InPatient> GetAllInPatientBAL()
       {
            List<InPatient> inpatientList;
            try
            {
                HMSDal inpatient = new HMSDal();
                inpatientList = inpatient.GetAllInPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inpatientList;
        }



        public static DataTable GetDoctorBAL()
        {
            DataTable doctorList;
            try
            {
                HMSDal patientDAL = new HMSDal();
                doctorList = patientDAL.GetDoctorDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return doctorList;
        }
        public static DataTable GetLabBAL()
        {
            DataTable labList;
            try
            {
                HMSDal labDAL = new HMSDal();
                labList = labDAL.GetLabDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labList;
        }
        public static DataTable GetRoomBAL()
        {
            DataTable roomList;
            try
            {
                HMSDal roomDAL = new HMSDal();
                roomList = roomDAL.GetRoomDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return roomList;
        }





        public static List<string> GetLabNosBAL()
        {
            List<string> listObj = null;
            try
            {
                listObj = HMSDal.GetLabNosDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }




        private static bool ValidateOutPatient(OutPatient Outpatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validOutPatient = true;
            if (Outpatient.PatientID == string.Empty)
            {
                validOutPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient ID can't  be empty");
            }
            else if (!Regex.IsMatch(Outpatient.PatientID, "^[0-9]{4}$"))
            {
                sb.Append("patient id should be 4 digits only\n");
                validOutPatient = false;
            }
            if (Outpatient.TreatmentDate == null)
            {
                sb.Append(Environment.NewLine + "Treatment Date is Required");
                validOutPatient = false;
            }
            if (Outpatient.LabNo == string.Empty)
            {
                validOutPatient = false;
                sb.Append(Environment.NewLine + "RoomNo  can't be empty.");
            }
            else if (!Regex.IsMatch(Outpatient.LabNo, "^[0-9]{1}$"))
            {
                sb.Append("LabNo should be 1 digit only\n");
                validOutPatient = false;
            }
            if (Outpatient.DoctorID == string.Empty)
            {
                validOutPatient = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            else if (!Regex.IsMatch(Outpatient.DoctorID, "^[0-9]{3}$"))
            {
                sb.Append("doctor id should be 3 digits only\n");
                validOutPatient = false;
            }

            if (validOutPatient == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validOutPatient;
        }


        public static bool AddOutPatientBAL(OutPatient OutPatient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidateOutPatient(OutPatient))
                {
                    HMSDal patientDAL = new HMSDal();
                    patientAdded = patientDAL.AddOutPatientDAL(OutPatient);
                    return patientAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }




        public static bool DeleteOutPatientBAL(string patientId)
        {
            bool PatientDeleted = false;
            try
            {
                if (patientId != null)
                {
                    HMSDal patientDAL = new HMSDal();

                    PatientDeleted = patientDAL.DeleteOutPatientDAL(patientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid OutPatient ID");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PatientDeleted;
        }



        public static bool UpdateOutPatientBAL(OutPatient outPatient)
        {
            bool outpatientUpdated = false;
            try
            {
                if (ValidateOutPatient(outPatient))
                {
                    HMSDal patientDAL = new HMSDal();
                    outpatientUpdated = patientDAL.UpdateOutPatientDAL(outPatient);
                    return outpatientUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outpatientUpdated;
        }


        public static List<OutPatient> GetAllOutPatientBAL()
        {
            List<OutPatient> outpatientList;
            try
            {
                HMSDal outpatient = new HMSDal();
                outpatientList = outpatient.GetAllOutPatientsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outpatientList;
        }


        public static OutPatient SearchOupatientByDocIDBAL(string doctorId)
        {
            OutPatient patient = null;

            try
            {
                if (doctorId != null)
                {
                    HMSDal patientDAL = new HMSDal();
                    patient = patientDAL.SearchOupatientByDocIDDAL(doctorId);
                }
                else
                {
                    throw new HMSException("Patient Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static OutPatient SearchOutPatientbyPatientIDBAL(string patientId)
        {
            OutPatient patient = null;

            try
            {
                if (patientId != null)
                {
                    HMSDal patientDAL = new HMSDal();
                    patient = patientDAL.SearchOutPatientbyPatientIDDAL(patientId);
                }
                else
                {
                    throw new HMSException("Patient Id is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        
        

        public static bool UpdateLabBAL(Lab lab)
        {
            bool LabUpdated = false;
            try
            {
                if (ValidateLab(lab))
                {
                    HMSDal LabDAL = new HMSDal();
                    LabUpdated = LabDAL.UpdateLabDAL(lab);
                    return LabUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabUpdated;
        }

        public static bool AddLabBAL(Lab lab)
        {
            bool LabAdded = false;
            try
            {
                if (ValidateLab(lab))
                {
                    HMSDal LabDAL = new HMSDal();
                    LabAdded = LabDAL.AddLabDAL(lab);
                    return LabAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabAdded;
        }

        private static bool ValidateLab(Lab lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLab = true;
            if (lab.LabNo == string.Empty)
            {
                validLab = false;
                sb.Append(Environment.NewLine
                    + "Lab No can't  be empty");
            }

            if (lab.PatientID == string.Empty)
            {
                validLab = false;
                sb.Append(Environment.NewLine + "PatientID  can't be empty.");
            }
            else if (!Regex.IsMatch(lab.PatientID, "^[0-9]{4}$"))
            {
                sb.Append("patient id should be 4 digits only\n");
                validLab = false;
            }

            if (lab.DoctorID == string.Empty)
            {
                validLab = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            else if (!Regex.IsMatch(lab.DoctorID, "^[0-9]{3}$"))
            {
                sb.Append("Doctor id should be 3 digits only\n");
                validLab = false;
            }
            if (lab.TestDate == null)
            {
                sb.Append(Environment.NewLine + "Test Date is Required");
                validLab = false;
            }

            if (validLab == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validLab;
        }

        public static Lab SearchLabbyPatientIDBAL(string patientId)
        {
            Lab lab = null;

            try
            {
                if (patientId != null)
                {
                    HMSDal LabDAL = new HMSDal();
                    lab = LabDAL.SearchLabbyPatientIDDAL(patientId);
                }
                else
                {
                    throw new HMSException("Patient is Required.");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lab;
        }

        public static bool DeleteLabBAL(string PatientId)
        {

            bool LabDeleted = false;
            try
            {
                if (PatientId != null)
                {
                    HMSDal LabDAL = new HMSDal();

                    LabDeleted = LabDAL.DeleteLabDAL(PatientId);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid Lab no");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabDeleted;
        }

        public static bool AddBillBAL(Bill bill)
        {
            bool BillAdded = false;
            try
            {
                if (ValidateBill(bill))
                {
                    HMSDal BillDAL = new HMSDal();
                    BillAdded = BillDAL.AddBillDAL(bill);
                    return BillAdded;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillAdded;
        }

        private static bool ValidateBill(Bill bill)
        {
            StringBuilder sb = new StringBuilder();
            bool validBill = true;
            if (bill.BillID == string.Empty)
            {
                validBill = false;
                sb.Append(Environment.NewLine
                    + "Bill No can't  be empty");
            }
            else if (!Regex.IsMatch(bill.BillID, "[B][0-9]{4}"))
            {
                sb.Append("BillId should start with B ");
                validBill = false;

            }
            if (bill.PatientID == string.Empty)
            {
                validBill = false;

                sb.Append(Environment.NewLine + "PatientID  can't be empty.");
            }
            else if (!Regex.IsMatch(bill.PatientID, "^[0-9]{4}$"))
            {
                sb.Append("patient id should be 4 digits only\n");
                validBill = false;
            }
            if (bill.DoctorID == string.Empty)
            {
                validBill = false;
                sb.Append(Environment.NewLine + "DoctorID  can't be empty.");
            }
            else if (!Regex.IsMatch(bill.DoctorID, "^[0-9]{3}$"))
            {
                sb.Append("doctor id  should be 3 digits only\n");
                validBill = false;
            }
            if (bill.OperationCharges == 0)
            {
                sb.Append(Environment.NewLine + "Operation charges  are Required");
                validBill = false;
            }


            if (validBill == false)
            {
                throw new HMSException(sb.ToString());
            }
            return validBill;
        }

        public static bool UpdateBillBAL(Bill bill)
        {
            bool BillUpdated = false;
            try
            {
                if (ValidateBill(bill))
                {
                    HMSDal BillDAL = new HMSDal();
                    BillUpdated = BillDAL.UpdateBillDAL(bill);
                    return BillUpdated;
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillUpdated;
        }

        public static bool DeleteBillBAL(string Billno)
        {
            bool BillDeleted = false;
            try
            {
                if (Billno != null)
                {
                    HMSDal BillDAL = new HMSDal();

                    BillDeleted = BillDAL.DeleteBillDAL(Billno);
                }
                else
                {
                    throw new Exceptions.HMSException("Invalid Bill no");
                }
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillDeleted;
        }

        public static List<Bill> GetAllBillsBAL()
        {
            List<Bill> billList;
            try
            {
                HMSDal bill = new HMSDal();
                billList = bill.GetAllBillsDAL();
            }
            catch (HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billList;
        }
    }
}
    
