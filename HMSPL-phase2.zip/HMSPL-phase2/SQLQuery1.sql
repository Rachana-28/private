USE [Training_19Sep19_Pune]
GO

/****** Object:  Table [8420].[Patient]    Script Date: 11/23/2019 9:18:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [8420].[Patient](
	[PatientID] [varchar](10) NOT NULL,
	[PatientName] [varchar](20) NULL,
	[Age] [int] NULL,
	[PatientWeight] [numeric](18, 0) NULL,
	[Gender] [varchar](10) NULL,
	[PAddress] [varchar](100) NULL,
	[MobileNo] [varchar](20) NULL,
	[Disease] [varchar](100) NULL,
	[DoctorID] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[PatientID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [8420].[Patient]  WITH CHECK ADD  CONSTRAINT [FK_Patient_Doctor] FOREIGN KEY([DoctorID])
REFERENCES [8420].[Doctor] ([DoctorID])
GO

ALTER TABLE [8420].[Patient] CHECK CONSTRAINT [FK_Patient_Doctor]
GO






CREATE TABLE [8420].[InPatient](
	[PatientID] [varchar](10) NOT NULL,
	[RoomNo] [varchar](20) NULL,
	[DoctorID] [varchar](20) NULL,
	[AdmissionDate] [date] NULL,
	[DischargeDate] [date] NULL,
	[LabNo] [varchar](20) NULL,
	[Amount] [real] NULL,
PRIMARY KEY CLUSTERED 
(
	[PatientID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [8420].[InPatient]  WITH CHECK ADD  CONSTRAINT [FK_InPatient_Doctor] FOREIGN KEY([DoctorID])
REFERENCES [8420].[Doctor] ([DoctorID])
GO

ALTER TABLE [8420].[InPatient] CHECK CONSTRAINT [FK_InPatient_Doctor]
GO

ALTER TABLE [8420].[InPatient]  WITH CHECK ADD  CONSTRAINT [FK_InPatient_Lab] FOREIGN KEY([LabNo])
REFERENCES [8420].[Lab] ([LabNo])
GO

ALTER TABLE [8420].[InPatient] CHECK CONSTRAINT [FK_InPatient_Lab]
GO

ALTER TABLE [8420].[InPatient]  WITH CHECK ADD  CONSTRAINT [FK_InPatient_RoomData] FOREIGN KEY([RoomNo])
REFERENCES [8420].[RoomData] ([RoomNo])
GO

ALTER TABLE [8420].[InPatient] CHECK CONSTRAINT [FK_InPatient_RoomData]
GO









CREATE TABLE [8420].[OutPatient](
	[PatientID] [varchar](20) NOT NULL,
	[TreatmentDate] [date] NULL,
	[DoctorID] [varchar](20) NULL,
	[LabNo] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[PatientID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [8420].[OutPatient]  WITH CHECK ADD  CONSTRAINT [FK_OutPatient_Doctor] FOREIGN KEY([DoctorID])
REFERENCES [8420].[Doctor] ([DoctorID])
GO

ALTER TABLE [8420].[OutPatient] CHECK CONSTRAINT [FK_OutPatient_Doctor]
GO






CREATE TABLE [8420].[Doctor](
	[DoctorID] [varchar](20) NOT NULL,
	[DoctorName] [varchar](20) NULL,
	[Department] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[DoctorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO









CREATE TABLE [8420].[BillData](
	[BillNo] [varchar](20) NOT NULL,
	[PatientID] [varchar](10) NULL,
	[PatientType] [varchar](20) NULL,
	[DoctorID] [varchar](20) NULL,
	[DoctorFee] [real] NULL,
	[RoomCharge] [real] NULL,
	[OperationCharges] [real] NULL,
	[MedicineFee] [real] NULL,
	[TotalDays] [int] NULL,
	[LabFee] [real] NULL,
	[TotalAmount] [real] NULL,
PRIMARY KEY CLUSTERED 
(
	[BillNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [8420].[BillData]  WITH CHECK ADD  CONSTRAINT [FK_BillData_Doctor] FOREIGN KEY([DoctorID])
REFERENCES [8420].[Doctor] ([DoctorID])
GO

ALTER TABLE [8420].[BillData] CHECK CONSTRAINT [FK_BillData_Doctor]
GO

ALTER TABLE [8420].[BillData]  WITH CHECK ADD  CONSTRAINT [FK_BillData_Patient] FOREIGN KEY([PatientID])
REFERENCES [8420].[Patient] ([PatientID])
GO

ALTER TABLE [8420].[BillData] CHECK CONSTRAINT [FK_BillData_Patient]
GO





CREATE TABLE [8420].[RoomData](
	[RoomNo] [varchar](20) NOT NULL,
	[TreatmentDate] [date] NULL,
	[DoctorID] [varchar](20) NULL,
	[LabNo] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[RoomNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [8420].[RoomData]  WITH CHECK ADD  CONSTRAINT [FK_RoomData_Doctor] FOREIGN KEY([DoctorID])
REFERENCES [8420].[Doctor] ([DoctorID])
GO

ALTER TABLE [8420].[RoomData] CHECK CONSTRAINT [FK_RoomData_Doctor]
GO








CREATE TABLE [8420].[Lab](
	[LabNo] [varchar](20) NOT NULL,
	[PatientID] [varchar](10) NULL,
	[DoctorID] [varchar](20) NULL,
	[TestDate] [date] NULL,
	[TestType] [varchar](50) NULL,
	[PatientType] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[LabNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO




