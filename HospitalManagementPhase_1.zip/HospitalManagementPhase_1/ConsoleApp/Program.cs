﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_Entities;
using HMS.Exceptions;
using HMS.BLL;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            HMS_BLL.setList();
            Program PP = new Program();
            PP.Accept();
           
         }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) { SetSerialization(); }

        private  void Accept()
        {
            char ch;
            do
            {
                PrintDetails();
                int option;
                Console.WriteLine("enter choice");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        PatientDataDetails();
                        break;
                    case 2:
                        PatientAppointmentDetails();
                        break;
                    case 3:
                        PatientBillDetails();
                        break;
                    case 4:
                        PatientLabDetails();
                        break;
                    default: Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("y for catalog N for exit");
                ch = Convert.ToChar(Console.ReadLine());

            }

            while (ch == 'y' || ch == 'N');
        }
        private static void PrintDetails()
        {
            Console.WriteLine("******************************");
            //Console.WriteLine("Enter ur option");
            Console.WriteLine("1.Patient data details");
            Console.WriteLine("2.Patient Appointment details");
            Console.WriteLine("3.Patient Bill Details");
            Console.WriteLine("4.Patient Lab details");

        }

        private static void PatientDataDetails()
        {
            Console.WriteLine("\n*********** Patient Data Details ***********");
            Console.WriteLine("1. Add Patient Details");
            Console.WriteLine("2. List all Patient Details");
            Console.WriteLine("3. Modify Patient Details");
            Console.WriteLine("4. Search Patient by Id");
            Console.WriteLine("5. Delete Patient Details");
            Console.WriteLine("Enter ur option :");

            int choice;
            //Console.Write("Enter your Choice :");
            choice = Int32.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    AddPatient();
                    break;
                case 2:
                    ListAllPatients();
                    break;
                case 3:
                    ModifyPatient();
                    break;
                case 4:
                    SearchPatientByID();
                    break;
                case 5:
                    DeletePatient();
                    break;
                default: Console.WriteLine("invalid choice");
                    break;


            }
        }
        private static void PatientAppointmentDetails()
        {
            Console.WriteLine("\n*********** Patient's Appointment Data Details ***********");
            Console.WriteLine("6. Add Patient Appointment data");
            Console.WriteLine("7. List all Patient Appointment Details");
            Console.WriteLine("8. Search Patient by Doctor Name");
            Console.WriteLine("9. Search Patient by Date of visit");
            Console.WriteLine("10. Search Patient by Date of Admission");
            Console.WriteLine("11. Search Patient by Date of Discharge");
            Console.WriteLine("12. Delete Patient's Appointment Details");
            int choice;
            Console.Write("Enter your Choice :");
            choice = Int32.Parse(Console.ReadLine());
            switch (choice)
            {
                case 6:
                    AddPatientAppointmentData();
                    break;
                case 7:
                    ListAllPatientAppointmentData();
                    break;
                case 8:
                    SearchPatientByDoctorName();
                    break;
                case 9:
                    SearchPatientByDoctorDOV();
                    break;
                case 10:
                    SearchPatientByDoctorDOA();
                    break;
                case 11:
                    SearchPatientByDoctorDOD();
                    break;
                case 12:
                    DeletePatientAppointmentDetails();
                    break;
                default:
                    Console.WriteLine("invalid choice");
                    break;

            }
        }
        private static void PatientBillDetails()
        {
            Console.WriteLine("\n*********** Patient's Bill Data Details ***********");
            Console.WriteLine("13. Add Patient's Bill");
            Console.WriteLine("14. List all Patient's Bill");
            Console.WriteLine("15. Search Patient's Bill By Id");
            Console.WriteLine("16. Delete Patient's Bill Details");
            int choice;
            //Console.Write("Enter your Choice :");
            choice = Int32.Parse(Console.ReadLine());
            switch (choice)
            {
                case 13:
                    AddBillReport();
                    break;
                case 14:
                    ListAllBill();
                    break;
                case 15:
                    SearchBillByID();
                    break;
                case 16:
                    DeletePatientBill();
                    break;
                default:
                    Console.WriteLine("invalid choice");
                    break;
            }

        }

        private static void PatientLabDetails()
        {
            Console.WriteLine("\n*********** Patient's Lab Report Details ***********");
            Console.WriteLine("17. Add Patient's Lab Report");
            Console.WriteLine("18. List all Patient's Lab Report");
            Console.WriteLine("19. Search Patient's Lab Report By Id");
            Console.WriteLine("20. Delete Patient's Lab Report Details");
            Console.WriteLine("21. Exit");
            Console.WriteLine("******************************************************************************************");
            int choice;
            //Console.Write("Enter your Choice :");
            choice = Int32.Parse(Console.ReadLine());
            switch (choice)
            {
                case 17:
                    AddLabReport();
                    break;
                case 18:
                    ListAllLabReport();
                    break;
                case 19:
                    SearchReportById();
                    break;
                case 20:
                    DeletePatientLabReport();
                    break;
                default:
                    Console.WriteLine("invalid choice");
                    break;
            }
        }
        
        private static void AddPatient()
        {
            try
            {
                Patient newPatient = new Patient();
                Console.WriteLine("Enter Patient ID :");
                newPatient.PatientId = Console.ReadLine();
                Console.WriteLine("Enter Patient Name :");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter Age :");
                newPatient.Age = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Weight :");
                newPatient.Weight = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter Gender('M' for Male and 'F' for Female :");
                newPatient.Gender = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("Enter Address :");
                newPatient.Address = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newPatient.PhoneNo = Console.ReadLine();
                Console.WriteLine("Enter Disease :");
                newPatient.Disease = Console.ReadLine();
                Console.WriteLine("Enter Doctor Id :");
                newPatient.DoctorId = Console.ReadLine();
                bool patientAdded = HMS_BLL.AddPatientBLL(newPatient);
                if (patientAdded)
                {
                    Console.WriteLine("Patient Added Successfully..!");
                }
                else
                {
                    Console.WriteLine("Patient Not Added");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddPatientAppointmentData()
        {
            try
            {
                Appointment newAppointment = new Appointment();
                Console.WriteLine("Enter Appointment ID :");
                newAppointment.AppointmentId = Console.ReadLine();
                Console.WriteLine("Enter Patient ID :");
                newAppointment.PatientId = Console.ReadLine();
                Console.WriteLine("Enter doctor Name :");
                newAppointment.DoctorName = Console.ReadLine();
                Console.WriteLine("Enter Room Number :");
                newAppointment.RoomNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter date of visit :");
                newAppointment.DateOfVisit = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Admission date :");
                newAppointment.AdmissionDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter discharge date :");
                newAppointment.DischargeDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter remarks :");
                newAppointment.Remarks = Console.ReadLine();
                bool patientAppointmentDataAdded = HMS_BLL.AddPatientAppointmentDataBLL(newAppointment);
                if (patientAppointmentDataAdded)
                    Console.WriteLine("Patient's Appointment Details Added");
                else
                    Console.WriteLine("Patient's Appointment Details not Added");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllPatients()
        {
            try
            {
                List<Patient> patientList = HMS_BLL.GetAllPatientsBLL();
                if (patientList != null && patientList.Count > 0)
                {
                    foreach (Patient patient in patientList)
                    {
                        Console.WriteLine("******************************************************************************************");
                        Console.WriteLine("Patient Id     :" + patient.PatientId);
                        Console.WriteLine("Patient Name   :" + patient.PatientName);
                        Console.WriteLine("Age            :" + patient.Age);
                        Console.WriteLine("Weight         :" + patient.Weight);
                        Console.WriteLine("Gender         :" + patient.Gender);
                        Console.WriteLine("Address        :" + patient.Address);
                        Console.WriteLine("Phone Number   :" + patient.PhoneNo);
                        Console.WriteLine("Disease        :" + patient.Disease);
                        Console.WriteLine("Doctor Id      :" + patient.DoctorId);
                        Console.WriteLine("******************************************************************************************");
                    }
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllPatientAppointmentData()
        {
            try
            {
                List<Appointment> appointmentList = HMS_BLL.GetAllPatientsAppointmentDataBLL();
                if (appointmentList != null && appointmentList.Count > 0)
                {

                    foreach (Appointment appointment in appointmentList)
                    {
                        Console.WriteLine("******************************************************************************************");
                        Console.WriteLine("AppointmentId :" + appointment.AppointmentId);
                        Console.WriteLine("Patient Id    :" + appointment.PatientId);
                        Console.WriteLine("Doctor Name   :" + appointment.DoctorName);
                        Console.WriteLine("Room Number   :" + appointment.RoomNo);
                        Console.WriteLine("Date Of Visit :" + appointment.DateOfVisit);
                        Console.WriteLine("Admission Date:" + appointment.AdmissionDate);
                        Console.WriteLine("Discharge Date:" + appointment.DischargeDate);
                        Console.WriteLine("Remarks       :" + appointment.Remarks);
                        Console.WriteLine("******************************************************************************************");
                    }
                }
                else
                {
                    Console.WriteLine("**********No Patient Appointment Details Available**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ModifyPatient()
        {
            try
            {
                string updatePatientID;
                Console.WriteLine("Enter PatientID to Update Details:");
                updatePatientID = Console.ReadLine();
                Patient updatedPatient = HMS_BLL.SearchPatientBLL(updatePatientID);
                if (updatedPatient != null)
                {
                    Console.WriteLine("Update PatientName :");
                    updatedPatient.PatientName = Console.ReadLine();
                    Console.WriteLine("Update Patient's Age:");
                    updatedPatient.Age = int.Parse(Console.ReadLine());
                    Console.WriteLine("Update Patient's Weight:");
                    updatedPatient.Weight = float.Parse(Console.ReadLine());
                    Console.WriteLine("Update Patient gender :");
                    updatedPatient.Gender = Convert.ToChar(Console.ReadLine());
                    Console.WriteLine("Update Address :");
                    updatedPatient.Address = Console.ReadLine();
                    Console.WriteLine("Update Phone Number :");
                    updatedPatient.PhoneNo = Console.ReadLine();
                    Console.WriteLine("Update Disease :");
                    updatedPatient.Disease = Console.ReadLine();
                    bool patientUpdated = HMS_BLL.UpdatePatientBLL(updatedPatient);
                    if (patientUpdated)
                        Console.WriteLine("Patient Details Updated Successfully");
                    else
                        Console.WriteLine("**********Patient Details Not Updated**********");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }


            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchPatientByID()
        {
            try
            {
                string searchPatientID;
                Console.WriteLine("Enter PatientID to Search:");
                searchPatientID = Console.ReadLine();
                Patient searchPatient = HMS_BLL.SearchPatientBLL(searchPatientID);
                if (searchPatient != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("Patient Id     :" + searchPatient.PatientId);
                    Console.WriteLine("Patient Name   :" + searchPatient.PatientName);
                    Console.WriteLine("Age            :" + searchPatient.Age);
                    Console.WriteLine("Weight         :" + searchPatient.Weight);
                    Console.WriteLine("Gender         :" + searchPatient.Gender);
                    Console.WriteLine("Address        :" + searchPatient.Address);
                    Console.WriteLine("Phone Number   :" + searchPatient.PhoneNo);
                    Console.WriteLine("Disease        :" + searchPatient.Disease);
                    Console.WriteLine("Doctor Id      :" + searchPatient.DoctorId);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchPatientByDoctorName()
        {
            try
            {
                string searchPatientByDoctor;
                Console.WriteLine("Enter Doctor's name to search:");
                searchPatientByDoctor = Console.ReadLine();
                Appointment searchPatientdoc = HMS_BLL.SearchPatientByDoctorBLL(searchPatientByDoctor);
                if (searchPatientdoc != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdoc.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdoc.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdoc.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdoc.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdoc.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdoc.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdoc.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdoc.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchPatientByDoctorDOV()
        {
            try
            {
                DateTime searchPatientDOV;
                Console.WriteLine("Enter Date of visit to search:");
                searchPatientDOV = Convert.ToDateTime(Console.ReadLine());
                Appointment searchPatientdov = HMS_BLL.SearchPatientDOVBLL(searchPatientDOV);
                if (searchPatientdov != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdov.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdov.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdov.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdov.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdov.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdov.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdov.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdov.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
        private static void SearchPatientByDoctorDOA()
        {
            try
            {
                DateTime searchPatientDOA;
                Console.WriteLine("Enter Date of admission to search:");
                searchPatientDOA = Convert.ToDateTime(Console.ReadLine());
                Appointment searchPatientdoa = HMS_BLL.SearchPatientDOABLL(searchPatientDOA);
                if (searchPatientdoa != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdoa.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdoa.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdoa.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdoa.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdoa.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdoa.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdoa.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdoa.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchPatientByDoctorDOD()
        {
            try
            {
                DateTime searchPatientDOD;
                Console.WriteLine("Enter Date of discharge to search:");
                searchPatientDOD = Convert.ToDateTime(Console.ReadLine());
                Appointment searchPatientdod = HMS_BLL.SearchPatientDODBLL(searchPatientDOD);
                if (searchPatientdod != null)
                {
                    Console.WriteLine("******************************************************************************************");
                    Console.WriteLine("AppointmentId :" + searchPatientdod.AppointmentId);
                    Console.WriteLine("PatientId     :" + searchPatientdod.PatientId);
                    Console.WriteLine("Doctor Name   :" + searchPatientdod.DoctorName);
                    Console.WriteLine("Room Number   :" + searchPatientdod.RoomNo);
                    Console.WriteLine("Date Of Visit :" + searchPatientdod.DateOfVisit);
                    Console.WriteLine("Admission Date:" + searchPatientdod.AdmissionDate);
                    Console.WriteLine("Discharge Date:" + searchPatientdod.DischargeDate);
                    Console.WriteLine("Remarks       :" + searchPatientdod.Remarks);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Patient Details Available**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void DeletePatient()
        {
            try
            {
                string deletePatientID;
                Console.WriteLine("Enter PatientID to Delete:");
                deletePatientID = Console.ReadLine();
                bool patientdeleted = HMS_BLL.DeletePatientBLL(deletePatientID);
                if (patientdeleted)
                    Console.WriteLine("Patient Deleted");
                else
                    Console.WriteLine("Patient not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatientAppointmentDetails()
        {
            try
            {
                string deletePatientAppointmentID;
                Console.WriteLine("Enter AppointmentID to Delete:");
                deletePatientAppointmentID = Console.ReadLine();
                bool patientAppointmentdeleted = HMS_BLL.DeletePatientAppointmentDetailsBLL(deletePatientAppointmentID);
                if (patientAppointmentdeleted)
                    Console.WriteLine("Patient's Appointment Details Deleted");
                else
                    Console.WriteLine("Patient's Appointment Details not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatientBill()
        {
            try
            {
                string deletePatientBillId;
                Console.WriteLine("Enter Patient's Bill ID to Delete:");
                deletePatientBillId = Console.ReadLine();
                bool patientBillDeleted = HMS_BLL.DeletePatientBillBLL(deletePatientBillId);
                if (patientBillDeleted)
                    Console.WriteLine("Patient's Bill Details Deleted");
                else
                    Console.WriteLine("Patient's Bill Details not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatientLabReport()
        {
            try
            {
                string deletePatientLabReportId;
                Console.WriteLine("Enter Patient's Lab Report ID to Delete:");
                deletePatientLabReportId = Console.ReadLine();
                bool patientLabReportDeleted = HMS_BLL.DeletePatientLabReportBLL(deletePatientLabReportId);
                if (patientLabReportDeleted)
                    Console.WriteLine("Patient's Lab Report Details Deleted");
                else
                    Console.WriteLine("Patient's Lab Report Details not Deleted ");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddBillReport()

        {

            string PatType;

            Console.WriteLine("Enter IP for Inpatient or OP for 9oOutPatient :");

            PatType = Console.ReadLine();

            try

            {

                if (PatType == "IP")

                {

                    Bill newBill = new Bill();

                    Console.WriteLine("Enter Bill ID :");

                    newBill.BillId = Console.ReadLine();

                    Console.WriteLine("Enter Patient ID :");

                    newBill.PatientId = Console.ReadLine();

                    Console.WriteLine("Enter Doctor Fees :");

                    newBill.DoctorFees = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Room Charges :");

                    newBill.RoomAmount = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Operation Charges :");

                    newBill.OperationCharges = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Medical bill :");

                    newBill.MedicalBill = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter TotalDays :");

                    newBill.TotalDays = Convert.ToInt16(Console.ReadLine());

                    Console.WriteLine("Enter Lab Fees :");

                    newBill.LabBill = Convert.ToDouble(Console.ReadLine());

                    bool patientLabReportDataAdded = HMS_BLL.AddPatientBillBLL(newBill);

                    if (patientLabReportDataAdded)

                        Console.WriteLine("Bill report Added");

                    else

                        Console.WriteLine("Bill report not Added");

                }

                else if (PatType == "OP")

                {

                    Bill newBill = new Bill();

                    Console.WriteLine("Enter Bill ID :");

                    newBill.BillId = Console.ReadLine();

                    Console.WriteLine("Enter Patient ID :");

                    newBill.PatientId = Console.ReadLine();

                    Console.WriteLine("Enter Doctor Fees :");

                    newBill.RoomAmount = 0;

                    newBill.OperationCharges = 0;

                    newBill.TotalDays = 0;

                    newBill.DoctorFees = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Medical bill :");

                    newBill.MedicalBill = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Enter Lab Fees :");

                    newBill.LabBill = Convert.ToDouble(Console.ReadLine());

                    bool patientLabReportDataAdded = HMS_BLL.AddPatientBillBLL(newBill);

                    if (patientLabReportDataAdded)

                        Console.WriteLine("Bill report Added");

                    else

                        Console.WriteLine("Bill report not Added");

                }

                else

                {

                    Console.WriteLine("Enter correct patient type");

                }

            }

            catch (HMS_Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

            Console.ReadKey();



        }

        private static void ListAllBill()
        {
            try
            {
                List<Bill> billList = HMS_BLL.GetAllPatientBillBLL();
                if (billList != null && billList.Count > 0)
                {

                    foreach (Bill bill in billList)
                    {
                        Console.WriteLine("**********BILL GENERATIONS**********");
                        Console.WriteLine("Bill Id                          :" + bill.BillId);
                        Console.WriteLine("Patient Id                       :" + bill.PatientId);
                        //Console.WriteLine("Patient Type                     :" + bill.PatientType);
                        //Console.WriteLine("Doctor Id                        :" + bill.DoctorId);
                        Console.WriteLine("Doctor Fees                      :" + bill.DoctorFees);
                        Console.WriteLine("Room Amount                      :" + bill.RoomAmount);
                        Console.WriteLine("Operation Theatre Amount         :" + bill.OperationCharges);
                        Console.WriteLine("Medical Bill                     :" + bill.MedicalBill);
                        Console.WriteLine("Total Days                       :" + bill.TotalDays);
                        Console.WriteLine("Lab Bill                         :" + bill.LabBill);
                        Console.WriteLine("------------------------------------------------------------------------------------------");
                        Console.WriteLine("Total amount to be Paid          :" + (bill.DoctorFees + bill.RoomAmount + bill.OperationCharges + bill.MedicalBill + bill.LabBill));
                        Console.WriteLine("------------------------------------------------------------------------------------------");
                        Console.WriteLine("******************************************************************************************");
                    }
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("**********No Bill Details Available**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddLabReport()
        {
            try
            {
                Lab lab = new Lab();
                Console.WriteLine("Enter Report ID :");
                lab.LabId = Console.ReadLine();
                Console.WriteLine("Enter Patient ID :");
                lab.PatientId = Console.ReadLine();
                Console.WriteLine("Enter Doctor ID :");
                lab.DoctorId = Console.ReadLine();
                Console.WriteLine("Enter Test date :");
                lab.TestDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Test type :");
                lab.TestType = (Console.ReadLine());
                Console.WriteLine("Enter Patient Type :");
                lab.PatientType = (Console.ReadLine());
                bool patientLabReportAdded = HMS_BLL.AddPatientLabReportBLL(lab);
                if (patientLabReportAdded)
                    Console.WriteLine("Lab report Added");
                else
                    Console.WriteLine("**********Lab report not Added**********");
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void ListAllLabReport()
        {
            try
            {
                List<Lab> labList = HMS_BLL.GetAllPatientLabReportBLL();
                if (labList != null && labList.Count > 0)
                {

                    foreach (Lab lab in labList)
                    {
                        Console.WriteLine("**********LAB REPORTS**********");
                        Console.WriteLine("Report Id    :" + lab.LabId);
                        Console.WriteLine("Patient Id   :" + lab.PatientId);
                        Console.WriteLine("Doctor Id    :" + lab.DoctorId);
                        Console.WriteLine("TestDate     :" + lab.TestDate);
                        Console.WriteLine("TestType     :" + lab.TestType);
                        Console.WriteLine("Patient Type :" + lab.PatientType);
                        Console.WriteLine("******************************************************************************************");
                    }
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("**********No Lab report Available**********");
                }
            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchBillByID()
        {
            try
            {
                string searchBillID;
                Console.WriteLine("Enter Bill ID to Search:");
                searchBillID = Console.ReadLine();
                Bill searchbill = HMS_BLL.SearchBillByIdBLL(searchBillID);
                if (searchbill != null)
                {
                    Console.WriteLine("**********BILL GENERATION**********");
                    Console.WriteLine("**********BILL GENRATIONS**********");
                    Console.WriteLine("Bill Id                          :" + searchbill.BillId);
                    Console.WriteLine("Patient Id                       :" + searchbill.PatientId);
                    Console.WriteLine("Patient Type                     :" + searchbill.PatientType);
                    Console.WriteLine("Doctor Id                        :" + searchbill.DoctorId);
                    Console.WriteLine("Doctor Fees                      :" + searchbill.DoctorFees);
                    Console.WriteLine("Room Amount                      :" + searchbill.RoomAmount);
                    Console.WriteLine("Operation Theatre Amount         :" + searchbill.OperationCharges);
                    Console.WriteLine("Medical Bill                     :" + searchbill.MedicalBill);
                    Console.WriteLine("Total Days                       :" + searchbill.TotalDays);
                    Console.WriteLine("Lab Bill                         :" + searchbill.LabBill);
                    Console.WriteLine("------------------------------------------------------------------------------------------");
                    Console.WriteLine("Total amount to be Paid          :" + (searchbill.DoctorFees + searchbill.RoomAmount + searchbill.OperationCharges + searchbill.MedicalBill + searchbill.LabBill));
                    Console.WriteLine("------------------------------------------------------------------------------------------");
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Bill Details Available**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }

        private static void SearchReportById()
        {
            try
            {
                string searchReportID;
                Console.WriteLine("Enter ReportID to Search:");
                searchReportID = Console.ReadLine();
                Lab searchreport = HMS_BLL.SearchReportByIdBLL(searchReportID);
                if (searchreport != null)
                {
                    Console.WriteLine("**********LAB REPORTS**********");
                    Console.WriteLine("Report Id    :" + searchreport.LabId);
                    Console.WriteLine("Patient Id   :" + searchreport.PatientId);
                    Console.WriteLine("Doctor Id    :" + searchreport.DoctorId);
                    Console.WriteLine("TestDate     :" + searchreport.TestDate);
                    Console.WriteLine("TestType     :" + searchreport.TestType);
                    Console.WriteLine("Patient Type :" + searchreport.PatientType);
                    Console.WriteLine("******************************************************************************************");
                }
                else
                {
                    Console.WriteLine("**********No Report Details Available**********");
                }

            }
            catch (HMS_Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
        private static void SetSerialization()
        {
            HMS_BLL.SetSerialization();
        }







    }
}





