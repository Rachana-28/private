﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
    [Serializable]
    public class Bill
    {
        public string BillId { get; set; }
        public string PatientId { get; set; }
        public string PatientType { get; set; }
        public string DoctorId { get; set; }
        public double DoctorFees { get; set; }
        public double RoomAmount { get; set; }
        public double OperationCharges { get; set; }
        public double MedicalBill { get; set; }
        public int TotalDays { get; set; }
        public double LabBill { get; set; }
        public double TotalAmount { get; set; }
    }
}
