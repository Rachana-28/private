﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
    [Serializable]
    public class Lab
    {

        public string LabId { get; set; }
        public string PatientId { get; set; }
        public string DoctorId { get; set; }
        public DateTime TestDate { get; set; }
        public string TestType { get; set; }
        public string PatientType { get; set; }
    }
}
